<?php
include ("Connection.php");
?>

<!DOCTYPE html>
<html>
<head>
	<title>FORM</title>
	<style>
		table{
			color: black;
			background-color: white;
			border-radius: 25px;
		}
		#btn{
			border-radius: 25px;
		}

	</style>
</head>

<body background="bg2.jpg">
	<br><br><br><br><br><br>
	<form action="" method="POST" autocomplete="off">
		<table align="center"  cellspacing="15">

			<tr><td>Id<td><input type="number" name="id" placeholder="Enter Id" required></td></tr>

			<tr><td>Name<td><input type="text" name="name" placeholder="Enter Name" required></td></tr>

			<tr><td>Department<td><input type="text" name="department"
			placeholder="Enter Department" required></td></tr>

			<tr><td>Address<td><input type="text" name="address"
			placeholder="Enter Address" required></td></tr>

			<tr><td>Salary<td><input type="number" name="salary"
			placeholder="Enter Salary" required></td></tr>

			<tr><td align="center" colspan="2"><input type="submit" name="submit" id="btn"></td></tr>

			<tr><td align="center" colspan="2"><a href="Fetch.php"><input type="button" name="" value="See Record"><a/></td></tr>

		</table>
	</form>

</body>
</html>


<?php
if(isset($_POST['submit'])){
	$id = $_POST['id'];
	$name = $_POST['name'];
	$department = $_POST['department'];
	$address = $_POST['address'];
	$salary = $_POST['salary'];

	//if($id!="" && $name!="" && $department!="" && $address!="" && $salary!=""){

	$query = "INSERT INTO EMP VALUES ('$id','$name','$department','
	$address','$salary')";

	$result = mysqli_query($con,$query);

	if($result){
			echo "Data inserted";
		}else{
			echo "Data not inserted";
		}
}
?>