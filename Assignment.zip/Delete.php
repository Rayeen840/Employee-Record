<?php
include ("Connection.php");
error_reporting(0);

$id=$_GET['id'];
$query = "DELETE FROM EMP WHERE id='$id'";
$result = mysqli_query($con,$query);

if($result){
	echo "<h1 style='text-align: center;'>Record delete from table</h1>"."<br><br>";
	echo "<a href='Fetch.php'><h2 style='text-align: center;'>GO BACK</h2></a>";
}else{
	echo "Failed to delete record from table";
}
?>