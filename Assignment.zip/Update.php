<?php
include("Connection.php");
error_reporting(0);

$id = $_GET['id'];
$name = $_GET['name'];
$department = $_GET['department'];
$address = $_GET['address'];
$salary = $_GET['salary'];

?>

<!DOCTYPE html>
<html>
<head>
	<title>UPDATE</title>
	<style>
		table{
			color: black;
			background-color: white;
			border-radius: 30px;
		}
		#btn{
			border-radius: 25px;
		}
	</style>
</head>

<body background="bg2.jpg">
	<br><br><br><br><br><br>
	<form action="" method="GET" autocomplete="off">
		<table align="center"  cellspacing="15">

			<tr>
				<td>Id</td>
				<td><input type="number" value="<?php echo "$id"?>" name="id" placeholder="Enter Id" required></td>
			</tr>

			<tr>
				<td>Name</td>
				<td><input type="text" value="<?php echo "$name"?>" name="name" placeholder="Enter Name" required></td>
			</tr>

			<tr>
				<td>Department</td>
				<td><input type="text" value="<?php echo "$department"?>" name="department"	placeholder="Enter Department" required></td>
			</tr>

			<tr>
				<td>Address</td>
				<td><input type="text" value="<?php echo "$address"?>" name="address" placeholder="Enter Address" required></td>
			</tr>

			<tr>
				<td>Salary</td>
				<td><input type="number" value="<?php echo "$salary"?>" name="salary" placeholder="Enter Salary" required></td>
			</tr>

			<tr>
				<td align="center" colspan="2"><input type="submit" name="submit" value="UPDATE" id="btn"></td>
			</tr>

		</table>
	</form>

</body>
</html>

<?php
if($_GET['submit']){
	$id = $_GET['id'];
	$name = $_GET['name'];
	$department = $_GET['department'];
	$address = $_GET['address'];
	$salary = $_GET['salary'];

	$query = "UPDATE EMP SET id='$id', name='$name', department='$department', address='$address', salary='$salary' where name='$name'";

	$result = mysqli_query($con,$query);

	if($result){
		echo "<script>alert('Record Updated')</script>";
	}else{
		echo "Failed to Update Record";
	}
}
?>