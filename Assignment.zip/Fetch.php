<!DOCTYPE html>
<html>
<head>
	<title>DISPLAY</title>
</head>
<body>
	<br><br><br><br><br>
	<table border="2" align="center" cellspacing="7">
		<tr>
			<th>ID</th>
			<th>NAME</th>
			<th>DEPARTMENT</th>
			<th>ADDRESS</th>
			<th>SALARY</th>
			<th colspan="2" align="center">OPERATION</th>
		</tr>
<?php
//error_reporting(0);
include ("Connection.php");

$query = "SELECT * FROM EMP";
$result = mysqli_query($con,$query);
$row = mysqli_num_rows($result);

if($row!=0){
	
	while ($display = mysqli_fetch_assoc($result)) {
		echo "<tr>
		         <td>".$display['id']."</td>
		         <td>".$display['name']."</td>
		         <td>".$display['department']."</td>
		         <td>".$display['address']."</td>
		         <td>".$display['salary']."</td>
		         
		         <td><a href='update.php?id=$display[id] & name=$display[name] & department=$display[department] & address=$display[address] & salary=$display[salary]'>Edit/Update</a></td>

		         <td><a href='Delete.php?id=$display[id]' onclick='return checkdelete()'>Delete</a></td>
		      </tr>";
	}
	//echo "Table has record";
}else{
	echo "No records found";
}

?>
	</table>
	<script>
		function checkdelete(){
			return confirm('Are you sure you want to Delete this Record');
		}
	</script>

	<a href="Form.php"><h2 style="text-align: center;">GO BACK</h2></a>

</body>
</html>


