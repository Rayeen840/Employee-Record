<?php
$con = mysqli_connect("localhost","root","","Record");
if($con){
	//echo "connection successfully";
}else{
	echo "connection failed".mysqli_connect_error();
}
?>